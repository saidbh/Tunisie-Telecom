<!-- Wrapper Start -->
<div class="wrapper">
    <!-- Sidebar  -->
    <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make('admin.partials._body_left_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Sidebar End -->
        <!-- TOP Nav Bar -->
        <?php echo $__env->make('admin.partials._app_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <!-- TOP Nav Bar End -->
    <!-- Page Content  -->

        <?php echo $__env->yieldContent('content'); ?>
    <!-- Content End -->
</div>
<!-- Wrapper END -->
<!-- Footer -->
<?php echo $__env->make('admin.partials._body_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer END -->
<?php /**PATH /var/www/html/laravel9/resources/views/admin/partials/_app_body.blade.php ENDPATH**/ ?>