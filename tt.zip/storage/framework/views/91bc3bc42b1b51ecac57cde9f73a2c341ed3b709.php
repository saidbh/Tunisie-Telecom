<?php $__env->startSection('content'); ?>
    <section class="sign-in-page bg-white">
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <div class="col-sm-6 align-self-center">
                    <div class="sign-in-from">
                        <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger m-0"><?php echo e(Session::get('error')); ?></div>
                        <?php endif; ?>
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success m-0"><?php echo e(Session::get('success')); ?></div>
                        <?php endif; ?>
                        <h1 class="mb-0">S'identifier</h1>
                        <p>Entrez votre adresse e-mail et votre mot de passe pour accéder au panneau d'administration.</p>
                            <form action="<?php echo e(route('login')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control mb-0" id="exampleInputEmail1" placeholder="Enter email">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Mot de passe</label>
                            
                            <input type="password" name="password" class="form-control mb-0" id="exampleInputPassword1" placeholder="Password">
                        </div>
                        <div class="d-inline-block w-100">
                            <div class="custom-control custom-checkbox d-inline-block mt-2 pt-1">
                                <input type="checkbox" class="custom-control-input" id="customCheck1">
                                <label class="custom-control-label" for="customCheck1">Se souvenir de moi</label>
                            </div>
                            <button type="submit" class="btn btn-primary float-right">S'identifier</button>
                            </form>
                        </div>
                        <div class="sign-info">
                            
                            <ul class="iq-social-media">
                                <li><a href="" target="_blank"><i class="ri-link"></i></a></li>
                                <li><a href="" target="_blank"><i class="ri-facebook-box-line"></i></a></li>
                                <li><a href="" target="_blank"><i class="ri-instagram-line"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 bg-primary text-center">
                    <div class="sign-in-detail text-white" style="background: url(<?php echo e(asset("assets/images/login/1.png")); ?>) no-repeat 0 0; background-size: cover; min-height:calc(100vh - 55px)">
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </section>

    <style>
        .iq-footer{
            margin:0px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel9/resources/views/Auth/login.blade.php ENDPATH**/ ?>