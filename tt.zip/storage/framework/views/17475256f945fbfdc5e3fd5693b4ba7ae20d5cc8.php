<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?> "></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<!-- Appear JavaScript -->
<script src="<?php echo e(asset('assets/js/jquery.appear.js')); ?>"></script>
<!-- Countdown JavaScript -->
<script src="<?php echo e(asset('assets/js/countdown.min.js')); ?>"></script>
<!-- Counterup JavaScript -->
<script src="<?php echo e(asset('assets/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.counterup.min.js')); ?>"></script>
<!-- Wow JavaScript -->
<script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
<!-- Apexcharts JavaScript -->
<script src="<?php echo e(asset('assets/js/apexcharts.js')); ?>"></script>
<!-- Slick JavaScript -->
<script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>
<!-- Select2 JavaScript -->
<script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>
<!-- Owl Carousel JavaScript -->
<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?> "></script>
<!-- Magnific Popup JavaScript -->
<script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<!-- Smooth Scrollbar JavaScript -->
<script src="<?php echo e(asset('assets/js/smooth-scrollbar.js')); ?> "></script>
<!-- morris chart JavaScript -->
<script src="<?php echo e(asset('assets/js/morris.js')); ?> "></script>
<script src="<?php echo e(asset('assets/js/raphael-min.js')); ?> "></script>
<script src="<?php echo e(asset('assets/js/morris.min.js')); ?> "></script>
<!-- lottie JavaScript -->
<script src="<?php echo e(asset('assets/js/lottie.js')); ?> "></script>
<script src="<?php echo e(asset('assets/js/core.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/charts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/animated.js')); ?>"></script>
<!-- high charts JavaScript -->
<script src="<?php echo e(asset('assets/js/highcharts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/highcharts-3d.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/highcharts-more.js')); ?>"></script>
<!-- fullcalendar JavaScript -->
<script src="<?php echo e(asset('assets/fullcalendar/core/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/fullcalendar/daygrid/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/fullcalendar/timegrid/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/fullcalendar/list/main.js')); ?>"></script>
<!-- bc paint JavaScript -->
<script src="<?php echo e(asset('assets/js/bcpaint.js')); ?>"></script>
<!-- Dragndrop JavaScript -->
<script src="<?php echo e(asset('assets/js/dragndrop.js')); ?>"></script>

<!-- Chart Custom JavaScript -->
<script src="<?php echo e(asset('assets/js/chart-custom.js')); ?> "></script>
<script src="<?php echo e(asset('assets/js/jquery-print.js')); ?> "></script>

<!-- Custom JavaScript -->
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>


<script src="https://www.amcharts.com/lib/4/maps.js"></script>
<script src="https://www.amcharts.com/lib/4/geodata/continentsLow.js"></script>
<script src="https://www.amcharts.com/lib/4/geodata/worldLow.js"></script>
<script src="https://www.amcharts.com/lib/4/themes/kelly.js"></script>
<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>

<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.66/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.66/vfs_fonts.js"></script>
<script src="https://cdn.jsdelivr.net/npm/html-to-pdfmake/browser.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.5/jspdf.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dom-to-image/2.6.0/dom-to-image.min.js" integrity="sha256-c9vxcXyAG4paArQG3xk6DjyW/9aHxai2ef9RpMWO44A=" crossorigin="anonymous"></script>
<?php /**PATH /var/www/html/laravel9/resources/views/admin/partials/_body_scripts.blade.php ENDPATH**/ ?>