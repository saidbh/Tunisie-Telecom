<!-- Sidebar  -->
<div class="iq-sidebar">
  <div class="iq-sidebar-logo d-flex justify-content-between">
    <a href="<?php echo e(route('admin.dashboard')); ?>">

      <span class="text-white">T T</span>
    </a>
    <div class="iq-menu-bt align-self-center">
      <div class="wrapper-menu">
        <div class="line-menu half start"></div>
        <div class="line-menu"></div>
        <div class="line-menu half end"></div>
      </div>
    </div>
  </div>
  <div id="sidebar-scrollbar">
    <nav class="iq-sidebar-menu">
      <ul id="iq-sidebar-toggle" class="iq-menu">
        <?php echo $__env->make(config('laravel-menu.views.bootstrap-items'), ['items' => $MyNavBar->roots()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </ul>
    </nav>
    <div class="p-3"></div>
  </div>
</div>
<?php /**PATH /var/www/html/laravel9/resources/views/admin/partials/_body_left_sidebar.blade.php ENDPATH**/ ?>