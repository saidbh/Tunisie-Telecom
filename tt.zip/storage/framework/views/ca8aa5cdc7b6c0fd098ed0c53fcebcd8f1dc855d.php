<?php $__env->startSection('content'); ?>
    This is the users interface !
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel9/resources/views/users/dashboard/index.blade.php ENDPATH**/ ?>