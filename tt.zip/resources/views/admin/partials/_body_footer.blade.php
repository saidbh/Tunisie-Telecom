<!-- Footer -->
<footer class="bg-white iq-footer">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6">
        <ul class="list-inline mb-0">
          <li class="list-inline-item"><a href="{{-- {{ route('privacy_policy') }} --}}">Privacy Policy</a></li>
          <li class="list-inline-item"><a href="{{-- {{ route('terms_of_service') }} --}}">Terms of Use</a></li>
        </ul>
      </div>
      <div class="col-lg-6 text-right"> Copyright 2021 <a href="#" target="_blank">Tunisie Telecom</a> All Rights Reserved.</div>
    </div>
  </div>
</footer>
<!-- Footer END -->
