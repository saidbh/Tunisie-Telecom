@extends('layouts.app')
@section('content')
    This is the users interface !
@endsection
